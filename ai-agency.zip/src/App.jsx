import { useEffect, useRef } from "react";
import { motion } from "motion/react";
import Hls from "hls.js";
import { ArrowUpRight, Play } from "lucide-react";

function useHls(ref, src) {
  useEffect(() => {
    if (!ref.current) return;
    if (Hls.isSupported()) {
      const hls = new Hls();
      hls.loadSource(src);
      hls.attachMedia(ref.current);
    } else {
      ref.current.src = src;
    }
  }, [src]);
}

const BlurText = ({ text }) => (
  <h1 className="text-5xl md:text-7xl italic text-center">
    {text.split(" ").map((w,i)=>(
      <motion.span key={i}
        initial={{opacity:0,y:40,filter:"blur(10px)"}}
        animate={{opacity:1,y:0,filter:"blur(0)"}}
        transition={{delay:i*0.08}}
        className="inline-block mr-2">{w}
      </motion.span>
    ))}
  </h1>
);

export default function App(){
  const ref = useRef();
  useHls(ref,"https://stream.mux.com/9JXDljEVWYwWu01PUkAemafDugK89o01BR6zqJ3aS9u00A.m3u8");

  return (
    <div className="bg-black text-white min-h-screen">
      <div className="fixed top-4 left-0 right-0 flex justify-between px-6">
        <div>●</div>
        <button className="bg-white text-black px-3 py-1 rounded-full flex items-center gap-1">
          Get Started <ArrowUpRight size={14}/>
        </button>
      </div>

      <section className="h-screen flex flex-col items-center justify-center px-6 text-center">
        <BlurText text="The Website Your Brand Deserves"/>
        <p className="mt-6 text-white/70">AI-powered web design</p>
        <div className="flex gap-4 mt-6">
          <button className="bg-white/10 px-5 py-2 rounded-full">Start</button>
          <button className="flex items-center gap-2"><Play size={16}/>Watch</button>
        </div>
      </section>

      <section className="relative h-[400px]">
        <video ref={ref} autoPlay loop muted className="absolute inset-0 w-full h-full object-cover"/>
      </section>
    </div>
  );
}
